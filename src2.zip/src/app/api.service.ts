import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(
    public http: HttpClient

  ) { }

  addPokemon(data){
    return this.http.post('http://localhost/backendionic/insert.php', data);
  }

  readPokemons(){
    return this.http.get('http://localhost/backendionic/read.php');
  }

  removePokemon(data){
    return this.http.post('http://localhost/backendionic/delete.php', data);
  }
}



