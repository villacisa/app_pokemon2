import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'sliders',
    pathMatch: 'full'
  },
  {
    path: 'sliders',
    loadChildren: () => import('./sliders/sliders.module').then( m => m.SlidersPageModule)
  },
  {
    path: 'sliders',
    loadChildren: () => import('./pages/sliders/sliders.module').then( m => m.SlidersPageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'home',
    loadChildren: () => import('./pages/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: 'formulari',
    loadChildren: () => import('./formulari/formulari.module').then( m => m.FormulariPageModule)
  },
  {
    path: 'formulari',
    loadChildren: () => import('./pages/formulari/formulari.module').then( m => m.FormulariPageModule)
  },
  {
    path: 'llista',
    loadChildren: () => import('./llista/llista.module').then( m => m.LlistaPageModule)
  },
  {
    path: 'llista',
    loadChildren: () => import('./pages/llista/llista.module').then( m => m.LlistaPageModule)
  },
  {
    path: 'detail/:id',
    loadChildren: () => import('./detail/detail.module').then( m => m.DetailPageModule)
  },
  {
    path: 'inici',
    loadChildren: () => import('./pages/inici/inici.module').then( m => m.IniciPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
