import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-llista',
  templateUrl: './llista.page.html',
  styleUrls: ['./llista.page.scss'],
})
export class LlistaPage implements OnInit {
  id;
  public pokemons: any = [];

  constructor(
    public _apiService: ApiService
  ) { 
    this.readPokemons();
  }

  ngOnInit() {
  }

  readPokemons(){
    this._apiService.readPokemons().subscribe((response) => {
      console.log(response);
        this.pokemons = response;
  });
  }

  removePokemon(id){
    console.log(id);
    let data = {
      id: this.id
    }
    /*this._apiService.removePokemon(data).subscribe((response) => {
      console.log(response);
  });*/
  //console.log(data.id);
  }

 /* Pokemons =  [{"nombre": "Pikachu",
                "tipo": "eléctrico",
                "icono_tipo": "Icon_Electric.png",
                "img": "Pikachu.png",
                "color": "warning"
              },{"nombre": "Charmander",
                "tipo": "fuego",
                "icono_tipo": "Icon_Fire.png",
                "img": "Charmander.png",
                "color": "secondary"
              },{"nombre": "Squirtle",
                "tipo": "agua",
                "icono_tipo": "Icon_Water.png",
                "img": "Squirtle.png",
                "color": "primary"
              },{"nombre": "Bulbasaur",
                "tipo": "hierba",
                "icono_tipo": "Icon_Grass.png",
                "img": "Bulbasaur.png",
                "color": "succes"
              }];
  */

}

//TENGO QUE CREAR EL READ.PHP EN EL LOCALHOST Y HACER EL BUCLE CON mysqli_fetch_object