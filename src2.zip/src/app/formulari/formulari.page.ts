import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-formulari',
  templateUrl: './formulari.page.html',
  styleUrls: ['./formulari.page.scss'],
})
export class FormulariPage implements OnInit {

  nombre;
  tipo;
  altura;
  peso;

  constructor(
    public _apiService: ApiService
  ) { }

  ngOnInit() {
  }

  addPokemon(){
    let data = {
      nombre: this.nombre,
      tipo: this.tipo,
      altura: this.altura,
      peso: this.peso

    }
    this._apiService.addPokemon(data).subscribe((response) => {
      console.log(response);
    });

    console.log(data.nombre, data.tipo, data.altura, data.peso);
  }

  

}
